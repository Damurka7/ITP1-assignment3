package numbers.damir_nurtdinov;

import numbers.do_not_change.Calculator;
import numbers.do_not_change.NumberCreator;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.*;

public class MyNumberCreator extends NumberCreator {

    public Random rnd = new Random();
    private int numberQuantity;

    /**
     * method
     * @return random type from the subclasses of Number
     */
    public String getRandomType(){
        final String listOfTypes[] = {"BigDecimal", "BigInteger", "Byte", "Double", "Float", "Integer", "Long", "Short"};
        int position = rnd.nextInt(listOfTypes.length);//8 elements in list of types
        String type=null;
        for (int i = 0; i < listOfTypes.length; i++) {
            if(i==position){
                type =listOfTypes[i];
                break;
            }
        }
        return type;
    }

    /**
     * user insert the amount of numbers in the future List
     * checks boundaries
     * @return
     */
    @Override
    public int validateAndSetNumberQuantity() {
        System.out.println("Insert amount of numbers ");
        Scanner input = new Scanner(System.in);
        try {
            this.numberQuantity = (int) input.nextDouble();
            if (numberQuantity >= MIN_NUMBER_QUANTITY && numberQuantity <= MAX_NUMBER_QUANTITY) {
                return numberQuantity;
            } else if (numberQuantity < MIN_NUMBER_QUANTITY) {
                System.out.println("your number out of boundary, try again");
                return validateAndSetNumberQuantity();
            } else {
                System.out.println("your number out of boundary, try again");
                return validateAndSetNumberQuantity();
            }
        } catch (InputMismatchException e) {
            System.out.println("You have inserted something different with numbers, try again");
            return validateAndSetNumberQuantity();
        }
    }

    /**
     * randomly generates List with elements which are subclass for Number
     * for each type it creates a random value in range from NUMBER_LOWER_BOUNDARY to NUMBER_UPPER_BOUNDARY
     * rnd does not include upper value, so everything is fine
     * it adds to list (value - NUMBER_UPPER_BOUNDARY)
     * @param numberQuantity the quantity of numbers in the list
     * @return the List
     */
    @Override
    public List<Number> generateNumbers(int numberQuantity) {
        List<Number> listOfNumbers = new ArrayList<>();
        for (int i = 0; i < numberQuantity; i++) {
            switch (getRandomType()) {
                case "BigDecimal":
                    BigDecimal bd = new BigDecimal(Math.random() + rnd.nextInt(NUMBER_UPPER_BOUNDARY-NUMBER_LOWER_BOUNDARY) - NUMBER_UPPER_BOUNDARY);//bd - BigDecimal
                    listOfNumbers.add(bd);
                    break;
                case "BigInteger":
                    BigInteger max = new BigInteger(String.valueOf((NUMBER_UPPER_BOUNDARY-NUMBER_LOWER_BOUNDARY)));//max of BigInt (absolute)
                    int len = max.bitLength();
                    BigInteger res =new BigInteger(len, rnd);//randomly creating positive big integer
                    while(res.compareTo(BigInteger.valueOf(NUMBER_UPPER_BOUNDARY))==1 || res.compareTo(BigInteger.valueOf(NUMBER_LOWER_BOUNDARY))==-1) {
                        res =new BigInteger(len, rnd);
                    }
                        int sign = rnd.nextInt(2);
                        if (sign == 0) { //returning sign
                            res = (BigInteger.ZERO).subtract(res);
                        }
                    listOfNumbers.add(res);
                    break;
                case "Byte":
                    int ranndomBaseByte=0;
                    if(NUMBER_UPPER_BOUNDARY-NUMBER_LOWER_BOUNDARY>256) {//if we in range, then create byte with its own bounds
                         ranndomBaseByte = -128 + rnd.nextInt(256);
                    }else{
                         ranndomBaseByte = NUMBER_LOWER_BOUNDARY + rnd.nextInt(NUMBER_UPPER_BOUNDARY-NUMBER_LOWER_BOUNDARY);
                    }
                    Byte bt = (byte) ranndomBaseByte;//bt - ByTe
                    listOfNumbers.add(bt);
                    break;
                case "Double":
                    Integer intgrForDouble = rnd.nextInt(NUMBER_UPPER_BOUNDARY-NUMBER_LOWER_BOUNDARY);//intgr - integer
                    Double dbl = intgrForDouble.doubleValue()+Math.random();//dbl - double
                    listOfNumbers.add((Double)(dbl-NUMBER_UPPER_BOUNDARY));
                    break;
                case "Float":
                    Integer intgrForFloat = rnd.nextInt(NUMBER_UPPER_BOUNDARY-NUMBER_LOWER_BOUNDARY);//intgr - integer
                    Float flt = intgrForFloat.floatValue()+(float)Math.random();//flt-float
                    listOfNumbers.add((Float)(flt-NUMBER_UPPER_BOUNDARY));
                    break;
                case "Integer":
                    Integer intgr = rnd.nextInt(NUMBER_UPPER_BOUNDARY-NUMBER_LOWER_BOUNDARY);//intgr - integer
                    listOfNumbers.add((Integer)( intgr-NUMBER_UPPER_BOUNDARY));
                    break;
                case "Long":
                    BigInteger biForLong = new BigInteger(String.valueOf(rnd.nextInt(NUMBER_UPPER_BOUNDARY-NUMBER_LOWER_BOUNDARY)));// - BigInteger for long
                    Long lng = biForLong.longValue();//lng - long
                    listOfNumbers.add((Long)(lng-NUMBER_UPPER_BOUNDARY));
                    break;
                default:
                    int ranndomBaseShort=0;
                    if (NUMBER_UPPER_BOUNDARY - NUMBER_LOWER_BOUNDARY > 65536) {
                        ranndomBaseShort = -32768 + rnd.nextInt(65536);
                    }else{
                        ranndomBaseShort = rnd.nextInt(NUMBER_UPPER_BOUNDARY - NUMBER_LOWER_BOUNDARY );
                    }
                    Short shrt = (short) ranndomBaseShort;//shrt - short
                    listOfNumbers.add((short)(shrt-NUMBER_UPPER_BOUNDARY));
            }
        }

        return listOfNumbers;
    }

    /**
     * This method allows to insert numbers into the list
     * of randomly chosen types. The user has to print the
     * values via console. The incorrectly printed data handled
     * user inserts number and method automatically assign a random type to it
     * it will round value if it has point and randomly assigned to int, byte, short
     * @return the list of numbers inserted by user
     */
    @Override
    public List<Number> insertNumbers(int numberQuantity) {
        System.out.println("Please, insert numbers");
        List<Number> listOfNumbers = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);
        String input = scanner.next();//insert data in string to handle errors
        for (int i = 0; i < numberQuantity; i++) {
                try{
                    if(!input.startsWith("00")) {
                        BigDecimal in_bd = new BigDecimal(input);//input big decimal will help to handle some errors which are connected to a size of type
                        if(in_bd.compareTo(BigDecimal.valueOf(NUMBER_LOWER_BOUNDARY))>=0 && in_bd.compareTo(BigDecimal.valueOf(NUMBER_UPPER_BOUNDARY))<=0) {//checking boundaries
                            switch (getRandomType()) {
                                case "BigDecimal":
                                    BigDecimal bd = new BigDecimal(input);//bd - BigDecimal
                                    listOfNumbers.add(bd);
                                    break;
                                case "BigInteger":
                                    BigInteger bi = in_bd.toBigInteger();//praise the  God for this method and other ones
                                    listOfNumbers.add(bi);
                                    break;
                                case "Byte":
                                    int bt =0;
                                    in_bd = in_bd.setScale(0, BigDecimal.ROUND_HALF_DOWN);
                                    byte byt = in_bd.byteValue();
                                    listOfNumbers.add(byt);
                                    //or I did this thing to return a value in byte boundaries, not byte value. But nothing was required with it.
//                                    if(in_bd.compareTo(BigDecimal.valueOf(-128))>=0&&in_bd.compareTo(BigDecimal.valueOf(127))<=0) {
//                                        bt = in_bd.intValue();
//                                        listOfNumbers.add((byte)bt);
//                                    }else if(in_bd.compareTo(BigDecimal.valueOf(-128))<0) {
//                                        bt = -128;
//                                        listOfNumbers.add((byte) bt);
//                                    }else{
//                                        bt = 127;
//                                        listOfNumbers.add((byte) bt);
//                                    }
                                    break;
                                case "Double":
                                    Double dbl = in_bd.doubleValue();//dbl - double
                                    listOfNumbers.add(dbl);
                                    break;
                                case "Float":
                                    Float flt = in_bd.floatValue();//flt-float
                                    listOfNumbers.add(flt);
                                    break;
                                case "Integer":
                                    Integer intgr = in_bd.intValue();//intgr - integer
                                    listOfNumbers.add(intgr);
                                    break;
                                case "Long":
                                    BigInteger res = in_bd.toBigInteger();
                                    Long lng = res.longValue();
                                    listOfNumbers.add(lng);
                                    break;
                                default:
                                    Short shrt = in_bd.shortValue();//shrt - short
                                    listOfNumbers.add(shrt);
                                    break;
                            }
                        }else{
                            System.out.println("Your number out of boundary. Try again");
                            i--;
                        }
                    }else{
                        System.out.println("you have inserted something different with numbers.");
                        System.out.println("Try again");
                        i--;
                    }
                }catch (NumberFormatException e){
                    System.out.println("you have inserted something different with numbers. Exception: "+e);
                    System.out.println("Try again");
                    i--;
                }
            if(i<numberQuantity-1) {//fixing some bugs
                input = scanner.next();
            }else{
                break;
            }
        }

        return listOfNumbers;
    }
}
