package numbers.damir_nurtdinov;

import numbers.do_not_change.Calculator;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

public class MyCalculator extends Calculator {


    /**
     * This is the constructor of a Calculator
     *
     * @param numbers the list of numbers
     */
    public MyCalculator(List<Number> numbers) {
        super(numbers);
    }

    /**
     * This method is summarizing double value all elements of
     * the input list of numbers
     *
     * @return the double sum of all elements
     */
    @Override
    public double summarize() {
        double sum=0;
        for (int i = 0; i < (this.getNumbers().size()); i++) {
            sum+=this.getNumbers().get(i).doubleValue();
        }
        return sum;
    }

    /**
     * This method is multiplying all elements of
     * the input list of numbers
     *
     * @return the double result of all element
     *         multiplication
     */
    @Override
    public double multiply() {
        double product=1;
        for (int i = 0; i < (this.getNumbers().size()); i++) {
            product*=this.getNumbers().get(i).doubleValue();
        }
        return product;
    }

    /**
     * This method allows deleting all negative numbers
     * from the list
     * at the beginning it converts all values to double
     */
    @Override
    public void deleteNegativeNumbers() {
        for (int i = 0; i < (this.getNumbers().size()); i++) {
            if(this.getNumbers().get(i).doubleValue()<0){
                this.getNumbers().remove(i);
                i--;
            }
        }
    }

    /**
     * This method is dividing each number of the
     * list by the divisor and rewrite the list values
     *
     * @param divisor the divisor
     */
    @Override
    public void divideBy(double divisor) {
        List<Number> newList = new ArrayList<>();
        for(Number element: this.getNumbers()){
            try {
                if(divisor!=0) {
                    if(element instanceof Double){
                        element = element.doubleValue() / divisor;
                        newList.add((Double) element);
                    } else if(element instanceof BigDecimal){
                        newList.add((BigDecimal)((BigDecimal) element).divide(BigDecimal.valueOf(divisor)));
                    } else if(element instanceof BigInteger){
                        BigDecimal currentElement = new BigDecimal((BigInteger)element);
                        BigDecimal biDivisor = new BigDecimal(divisor);
                        newList.add(currentElement.divide(biDivisor, RoundingMode.HALF_DOWN).toBigInteger());
                    } else if(element instanceof Byte){
                        newList.add((byte)(element.byteValue()/divisor));
                    } else if(element instanceof Float){
                        newList.add((float)element.floatValue() /divisor);
                    } else if(element instanceof Integer){
                        newList.add((int)(element.intValue()/divisor));
                    } else if(element instanceof Long){
                        newList.add((long)(element.longValue()/divisor));
                    } else if(element instanceof Short){
                        newList.add((short)element.shortValue()/divisor);
                    }
                }else{
                    throw new ArithmeticException("ArithmeticException because of division by zero");
                }
            }catch (ArithmeticException e){
                System.err.println(e.getMessage());
                break;
            }
        }
        this.getNumbers().clear();
        this.getNumbers().addAll(newList);
    }

    /**
     * This method is calculating square root
     * for each element of the array and updating the
     * list values
     * if element is negative, throw exception
     */
    @Override
    public void getSquareRoot() {
        List<Number> newList = new ArrayList<>();
        for(Number number: this.getNumbers()){
            try{
                if(number.doubleValue()>=0){
                    if(number instanceof Double){
                        number=Math.sqrt(number.doubleValue());
                        newList.add((Double)number);
                    } else if(number instanceof BigDecimal){
                        number=Math.sqrt(number.doubleValue());
                        newList.add((BigDecimal)number);
                    } else if(number instanceof BigInteger){
                        number=Math.sqrt(number.doubleValue());
                        BigInteger bi_number = BigInteger.valueOf(number.intValue());
                        newList.add((BigInteger)bi_number);
                    } else if(number instanceof Byte){
                        number=Math.sqrt(number.doubleValue());
                        Byte bte = number.byteValue();
                        newList.add(bte);
                    } else if(number instanceof Float){
                        number=Math.sqrt(number.floatValue());
                        newList.add((Float)number);
                    } else if(number instanceof Integer){
                        number=Math.sqrt(number.doubleValue());
                        Integer i_number = number.intValue();
                        newList.add(i_number);
                    } else if(number instanceof Long){
                        number=Math.sqrt(number.doubleValue());
                        Long long_number = number.longValue();
                        newList.add(long_number);
                    } else if(number instanceof Short){
                        number=Math.sqrt(number.doubleValue());
                        Short sh_number = number.shortValue();
                        newList.add(sh_number);
                    }
                }else{
                throw new ArithmeticException("ArithmeticException because of negative value");
                    }
            }catch (ArithmeticException e){
                System.err.println(e.getMessage());
                break;
            }
        }
        this.getNumbers().clear();
        this.getNumbers().addAll(newList);
    }
}
